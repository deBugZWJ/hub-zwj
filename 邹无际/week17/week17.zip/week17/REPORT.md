# 实验报告 — 基于 GRPO 的强化学习提升模型做数学题能力

## 0. 摘要

本实验在消费级显卡上，用 **Qwen2-0.5B** 小模型完整跑通 **GRPO（Group Relative Policy Optimization）** 强化学习训练闭环：通过**可程序化验证的规则奖励**（无需奖励模型、无需人工标注），让模型同时学会"输出 `<answer>` 格式"和"算得更准"两件事，并用**同评估集配对对比**量化训练前后差异。

核心结果：训练集内难度正确率大幅提升（两位数×一位数 L5 从 **20% → 88%**）；**未训练的难度也泛化提升**（表内乘法 L4 从 56% → 100%）；但**超出能力边界的难度几乎不涨**（两位数×两位数 L6 仅 8% → 24%）。得出的主要结论：**RL 在模型能力边界内重排概率分布，能泛化，但不能凭空创造能力**。此外，LoRA（r=16）在显存减半的同时效果反超全量微调，但熵崩溃更严重。

---

## 1. 研究问题与目标

| 子问题 | 目标 |
|--------|------|
| GRPO 能否让 0.5B 模型学会"格式 + 正确"两件事 | 验证可验证奖励 RL（RLVR）在小模型上的有效性 |
| "提升能力"是否只是背题 | 用**未训练难度**做泛化对照，排除过拟合题目 |
| RL 的能力边界在哪 | 用难度旋钮（位数即难度）测出边界内/外差异 |
| 全量 vs LoRA 怎么选 | 同设置下的对照实验，显存/效果/熵崩溃三维比较 |

**为什么选算术题**：答案可程序精确判定（零成本、零噪声）；位数即难度旋钮，可把基线恰好调到 GRPO 可学习的区间；答案只占几个 token，生成快，20万+ 采样分钟级。

---

## 2. 方法

### 2.1 任务与数据

按 6 个难度级别程序化生成算术题（`make_problem`）：

| 难度 | 题型 | 设计意图 |
|------|------|---------|
| L1_add_1digit | 个位数加法 | 接近满分，sanity check，**不进训练集** |
| L2_addsub_2digit | 两位数加减 | 甜区候选（训练集 25%） |
| L3_addsub_3digit | 三位数加减 | 主训难度（训练集 50%） |
| L4_mul_1digit | 表内乘法 | 泛化评估，**不进训练集** |
| L5_mul_2x1digit | 两位数×一位数 | 主训难度（训练集 25%） |
| L6_mul_2x2digit | 两位数×两位数 | 太难，**不进训练集**，测能力边界 |

训练集 1000 题，难度配比 L3/L5/L2 = 50%/25%/25%，seed=123。评估集每难度 50 题，seed=42（**评估 seed 与基线一致**，保证前后是同一批题，可配对比较）。

### 2.2 奖励设计（复合、解耦）

```
reward = reward_correct(1.0 正确/0.0 错误) + reward_format(0.2 符合 <answer>N</answer>)
```

- **正确分用宽松解析**：有 `<answer>` 标签取标签内数字；无标签则取输出中**最后一个数字**。原因：基线期模型完全无标签（格式率≈0），若严格要求标签内数字，正确分也是 0 → 组内全零 → advantage 全 0 → 训练无法冷启动。宽松解析保证启动即有梯度。
- **格式分权重 0.2 刻意小于正确分**：制造"主次信号竞争"的真实场景，用于观察 reward shaping 的权重权衡。

### 2.3 GRPO 原理与关键配置

GRPO 与 PPO 的核心区别：**去掉价值网络**，对同一 prompt 采样的 K 条回复，用组内奖励均值/标准差归一化得到 advantage：

```
advantage_i = (r_i − mean(r_group)) / std(r_group)
```

本项目更进一步：`beta=0`，**连参考模型都省掉**（TRL 默认），KT 系数为 0，省约 1GB 显存。

| 配置 | 取值 | 说明 |
|------|------|------|
| `num_generations` | 8 | 组内采样数 K；K 太小 advantage 噪声大，太大生成慢 |
| `beta` | 0.0 | KL=0，不加载参考模型 |
| `epsilon` | 0.2 | PPO-clip 裁剪范围 |
| `temperature` | 1.0 | 采样温度，保证组内多样性（GRPO 的"训练燃料"） |
| `max_completion_length` | 64 | 答案只需几个 token |
| 学习率 | 全量 2e-6 / LoRA 2e-4 | 全量 RL 微调量级；LoRA 自动切换 |
| 批次 | 8 completions × 累积 4 | 每优化步 = 4 prompt × 8 采样 = 32 条 completions |
| `max_steps` | 200 | 总优化步数（800 prompt × 8 采样 ≈ 0.8 epoch） |
| dtype | bf16 | 见 §7 踩坑 |
| gradient_checkpointing | 关 | transformers 5.x 下开启会损坏 generate 输出 |

### 2.4 选题方法论（本项目最重要的部分）

GRPO 的梯度来自**组内奖励方差**：一个 prompt 采 K 条，**全对或全错时 advantage = 0，该组零梯度**。因此选题的核心指标是 **informative group rate**（组内 0 < 正确数 < K 的比例）。基线摸底实测各难度该比例，据此定配比（进训练集的 L2/L3/L5 的 informative 都在 0.66~0.76；L1 太易、L6 太难，L4 留作泛化）。

---

## 3. 实验设置

| 项 | 说明 |
|----|------|
| 模型 | Qwen2-0.5B（`Qwen2ForCausalLM`，bf16，带 chat_template） |
| 硬件 | NVIDIA RTX 3060 12GB（比文档原用 4060 Laptop 8GB 更充裕） |
| 框架 | torch 2.6.0+cu126 / transformers 5.5.3 / trl 0.21.0 / accelerate |
| 兼容层 | `src/trl_compat.py`（trl 0.21 × transformers 5.x 补丁，**必须最先 import**） |
| 评估 | 6 难度 × 50 题 × (greedy + K=8 采样)，seed=42 |

---

## 4. 结果

### 4.1 训练前后对比（同一评估集，50 题/难度；格式率 / greedy 正确率 / pass@8）

| 难度 | 在训练集 | 格式率 基线→全量→LoRA | greedy 正确 基线→全量→LoRA | pass@8 基线→全量→LoRA |
|------|:---:|---|---|---|
| L1 个位数加法 | — | 0.00 → 0.96 → **1.00** | 0.98 → 1.00 → 1.00 | 1.00 → 1.00 → 1.00 |
| L2 两位数加减 | √ | 0.02 → 1.00 → **1.00** | 0.76 → 0.98 → 0.98 | 0.96 → 1.00 → 0.98 |
| L3 三位数加减 | √ | 0.02 → 0.96 → **1.00** | 0.40 → 0.90 → **0.92** | 0.76 → 0.94 → 0.94 |
| L4 表内乘法 | — | 0.00 → 0.82 → **1.00** | 0.56 → 1.00 → 1.00 | 0.88 → 1.00 → 1.00 |
| L5 两位×一位 | √ | 0.00 → 0.98 → **1.00** | 0.20 → 0.88 → **0.94** | 0.66 → 0.98 → **1.00** |
| L6 两位×两位 | — | 0.04 → 0.98 → **1.00** | 0.08 → 0.24 → **0.28** | 0.24 → 0.38 → **0.40** |

### 4.2 训练曲线关键点（`outputs/train_log*.json`）

| 指标 | 全量 (step5 → step200) | LoRA (step5 → step200) |
|------|:---:|:---:|
| reward_correct 组均值 | 0.550 → 0.844 | 0.700 → 0.950 |
| reward_format 组均值 | 0.010 → 0.176 | 0.024 → 0.200 |
| frac_reward_zero_std（退化组比例） | 0.10 → 0.30 | 0.15 → 0.80 |
| 策略熵 | 0.573 → 0.102 | 0.360 → 0.018 |

曲线解读：正确分前 25 步从 ~0.55 陡升到 0.85+（简单题和格式先收敛）；格式分缓慢爬升到 0.17~0.20（注意权重换算：格式分 0.2/次，0.176 均值 ≈ 88% 采样已带格式，涨得慢是**组内归一化下 0.2 增量被 1.0 正确性方差稀释**——这正是复合奖励设计的教学点）。

---

## 5. 讨论与结论

1. **格式学习几乎满分且完全泛化**：所有难度（含没训过的）格式率到 0.82~1.00。格式是表层行为，RL 极易学会。
2. **训练集内正确率大幅提升**：L5 从 0.20 → 0.88（4.4 倍）、L3 从 0.40 → 0.90。
3. **未训练难度也在涨（能力泛化）**：L4 未进训练集，正确率 0.56 → 1.00。说明 RL 不是背题，而是在强化"做对算术"的内部回路。
4. **超出能力边界几乎不涨**：L6 仅 0.08 → 0.24，pass@8 也仅 0.38。经典结论：**RL 在能力边界内重排概率分布，不能凭空创造能力**。两位数乘法的多步进位超出 0.5B 能力边界，给奖励也学不会。
5. **LoRA 反超全量（反直觉）**：LoRA 正确率 L3 0.92/0.90、L5 0.94/0.88、L6 0.28/0.24 全部略胜，且显存几乎减半（3.09 vs 6.07GB）。原因：小模型短训练下，LoRA 只动 0.28% 参数（强正则）+ 高等效学习率（2e-4 vs 2e-6，100×），收敛更快更稳；全量 bf16 在 200 步短训练反受单步噪声扰动。
6. **LoRA 的隐性代价——熵崩溃更严重**：全量熵 0.57→0.10，LoRA 熵 0.57→**0.02**；LoRA 的 `frac_reward_zero_std` 后期高达 0.80（绝大多数组全对/全错），说明策略已近确定性、探索枯竭。这是 LoRA 在长训练/难任务上的隐患，本项目任务简单、200 步就到顶，未暴露。

**教学结论**：参数少 ≠ 效果差。小模型 + 短训练 + 可验证奖励的 RL 场景里，LoRA 是性价比之王，但必须看 `entropy` 和 `frac_reward_zero_std` 两条曲线预警探索枯竭。

---

## 6. 复现指南（Windows）

### 6.1 环境准备

```bash
# 1) 用 PyTorch 官方索引安装带 CUDA 的 torch（关键：+cu126 本地版本号在普通 PyPI 不存在）
pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cu126
# 2) 安装其余依赖
pip install -r requirements.txt
```

> 注意：`requirements.txt` 里 `torch==2.6.0+cu126` 带本地版本号，**直接 `pip install -r requirements.txt` 会报找不到该版本**，必须先用上面的官方索引命令装 torch，或 `pip install -r requirements.txt` 前先装好 torch。

### 6.2 运行流程（都从项目根目录执行）

```bash
cd grpo_arithmetic

# Step 1 基线摸底（定难度）
python src/probe_baseline.py --quick        # 快速：每难度 10 题，验证流程
python src/probe_baseline.py                # 全量：每难度 50 题（约 30 秒）

# Step 2 GRPO 训练
python src/train_grpo.py --max_steps 3 --tag smoke   # 冒烟测试：验证显存与流程
python src/train_grpo.py                    # 完整训练：200 步（全量约 3-5 分钟）
python src/train_grpo.py --lora             # 显存不足时降级 LoRA

# Step 3 训练后评估（必须 --seed 42 与基线一致）
python src/probe_baseline.py --model outputs/grpo_ckpt --out outputs/post_train_probe.json --seed 42
python src/probe_baseline.py --model outputs/grpo_lora_ckpt --out outputs/post_train_probe_lora.json --seed 42

# Step 4 对比分析
python src/compare_results.py
```

> **模型路径**：两个脚本顶部 `MODEL_PATH` 已指向本机现有模型
> `C:\Users\Zs106\.cache\modelscope\models\Qwen--Qwen2-0.5B\snapshots\master`。
> 如需换模型，改 `src/probe_baseline.py` 和 `src/train_grpo.py` 顶部即可。

### 6.3 已知注意事项

- **必须从项目根运行**：`train_grpo.py` 用 `import trl_compat` 和 `from probe_baseline import ...`，依赖脚本目录在 `sys.path`（从项目根 `python src/xxx.py` 即可满足）。
- **模型是 base 版**（modelscope 缓存为 `Qwen2-0.5B` 非 `-Instruct`），带 chat_template 可正常运行；但其指令遵循基线比 Instruct 版弱，若想紧贴文档基准，建议换 `Qwen2-0.5B-Instruct`。
- **全量 checkpoint 权重未保留**：当前 `outputs/grpo_ckpt/` 只有配置/分词器（约 11MB），无 `model.safetensors`。要复用全量模型需重新训练；LoRA（`outputs/grpo_lora_ckpt/`，含 8.6MB adapter）完整可用。
- **健康训练标志**：前 25 步 `rewards/reward_correct/mean` 从 ~0.55 升到 0.85+；若奖励恒 0 或补全乱码，见 `USAGE_GUIDE.md` §4。

---

## 7. 踩坑记录（实测定位）

| 问题 | 根因 | 解法 |
|------|------|------|
| `from trl import GRPOTrainer` 崩在 `import vllm` | trl 0.21 用 transformers 私有 `_is_package_available()`；transformers 5.x 改返回 `(bool, version)` 元组且恒 truthy → trl 误判可选包已装 | `src/trl_compat.py` 在 import trl 前把元组打的成真实布尔 |
| `Qwen2ForCausalLM` 报缺 `warnings_issued` | transformers 5.x 移除警告去重字典，trl 0.21 仍读写 | trl_compat 给 `PreTrainedModel` 补类级空字典 |
| 采样补全乱码、奖励全 0 | transformers 5.x 下 gradient checkpointing + train 模式让 `generate` 前向损坏 | 关闭 `gradient_checkpointing` |
| 一步后 290 个权重张量 NaN/Inf | 本地 `config.json` 写 `torch_dtype: float16` → 按 fp16 加载 → AdamW `eps=1e-8` 在 fp16 下溢出为 0 → 0/0=NaN、m/ε=Inf | `model_init_kwargs={"torch_dtype": "bfloat16"}` 显式 bf16 |

---

*本报告引用的全部数字来自本机 `outputs/` 下已有的真实评估记录（`baseline_probe.json`、`post_train_probe.json`、`post_train_probe_lora.json`、`train_log*.json`），与 `ARCHITECTURE.md` 一致。*
